<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Quantox | Senior PHP Backend Developer Test Application</title>

        <link href="resources/styles/style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div class="flex">
            <div class="flex-container">
                <div class="navigation-bar">
                    <a class="fl" href="<?= URL ?>">Home</a>
                    <?php if (Session::Get("user_logged_in") == true): ?>
                    <a class="fl" href="<?= URL ?>search">Search</a>
                    <a class="fr" href="<?= URL ?>logout">Log out</a>
                    <?php else: ?>
                    <a class="fr" href="<?= URL ?>login">Login</a>
                    <a class="fr" href="<?= URL ?>register">Register</a>
                    <?php endif; ?>
                </div>
                <div class="content">