                    <?php if (isset($_GET['action'])) { Authentication::Login(); } ?>
                    <form method="POST" action="<?=URL?>login?action">
                        <input type="email" name="email" placeholder="Email address" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <input type="submit" value="Login">
                    </form>