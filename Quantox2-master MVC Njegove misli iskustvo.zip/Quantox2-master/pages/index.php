                    <?php if (Session::Get("user_logged_in") == true): ?>
                    <p>Welcome, <?= Session::Get("user_name")?>!</p>
                    <?php else: ?>
                    <p>Welcome, please login!</p>
                    <?php endif;