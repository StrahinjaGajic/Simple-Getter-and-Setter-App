                    <form method="GET" action="<?=URL?>search">
                        <input type="text" name="query" placeholder="Search text" value="<?= empty($_GET['query']) ? "" : $_GET['query'] ?>">
                        <input type="submit" value="Search">
                    </form>

                    <?php if (isset($_GET['query'])): ?>
                    <div class="search-results">
                        <h4>Search results: </h4>
                        <?php if (Search::Query($_GET['query']) == 0): ?>
                        <p>No results</p>
                        <?php else: ?>
                        <?php foreach (Search::Query($_GET['query']) as $result): ?>
                        <div class="item">
                            <div class="left-col">
                                <h1><?= $result->id ?></h1>
                            </div>
                            <div class="right-col">
                                <h3><?= $result->name ?></h3>
                                <p><?= $result->email ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>