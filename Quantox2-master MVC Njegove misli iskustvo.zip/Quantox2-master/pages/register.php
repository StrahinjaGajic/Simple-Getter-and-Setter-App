                    <?php if (isset($_GET['action'])) { Authentication::Register(); } ?>
                    <form method="POST" action="<?=URL?>register?action">
                        <input type="email" name="email" placeholder="Email address" required>
                        <input type="text" name="name" placeholder="First and last name" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <input type="password" name="password_repeat" placeholder="Password (repeat)" required>
                        <input type="submit" value="Register">
                    </form>