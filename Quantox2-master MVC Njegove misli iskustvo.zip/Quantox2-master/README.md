# Installation guide
No additional libraries used.

To install, simply import `quantox.sql` to your database, edit `core/config.php` and you are good to go.

# Bugs
`Authentication::Logout()` not working. Session won't destroy for some unknown reason (at least unknown to me).
