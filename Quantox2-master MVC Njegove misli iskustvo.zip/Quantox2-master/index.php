<?php

// Include the configuration file where we store some basic 
// values like url of the website, database parameters, etc...
require_once("core/config.php");

// Include some basic classes
require_once("core/database.php");
require_once("core/session.php");
require_once("core/view.php");
require_once("core/search.php");

// Include our authentication class that will handle user
// login, register and logout
require_once("core/authentication.php");

// Check if user specifically asked for a page
// If yes, show him the page if it exists
// if not, show him homepage
$page = isset($_GET['page']) ? $_GET['page'] : "index";

// Show requested page combined with our header and 
// footer template so all of our pages look same
View::Render($page);

?>