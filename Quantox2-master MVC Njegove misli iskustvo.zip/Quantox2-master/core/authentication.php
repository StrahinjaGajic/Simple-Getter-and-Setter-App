<?php

class Authentication {
    public static function Register() {
        // Create a new Database instance
        $db = new Database();

        // Check if fields are empty
        if (empty($_POST['email'])) { echo "Email field is empty."; return; }
        if (empty($_POST['name'])) { echo "Name field is empty."; return; }
        if (empty($_POST['password'])) { echo "Password field is empty."; return; }
        if (empty($_POST['password_repeat'])) { echo "Password (repeat) field is empty."; return; }

        // Check if passwords match
        // Show error if they don't match
        // Continue with registration if they match
        if ($_POST['password'] != $_POST['password_repeat']) { 
            echo "Password do not match"; 
            return; 
        } else {
            // Escape email and name
            $email = htmlentities($_POST['email'], ENT_QUOTES);
            $name = htmlentities($_POST['name'], ENT_QUOTES);

            // Store hash of the password in the database for more security
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT, array('cost' => 10));

            // Check if there's already an user with entered email
            $query = $db->prepare("SELECT * FROM users WHERE email = :email;");
            $query->execute(array(':email' => $email));
            
            $count =  $query->rowCount();            

            if ($count == 1) {
                echo "User with email: '$email' already exists.";
                return;
            } else {
                // Insert new user into the database
                $query = $db->prepare("INSERT INTO users (email, name, password) VALUES(:email, :name, :password);");
                $query->execute(array(
                    ':email' => $email, 
                    ':name' => $name, 
                    ':password' => $password
                ));                    
                
                $count =  $query->rowCount();

                if ($count == 1) {
                    echo "Registration successful. You can login now.";
                } else {
                    echo "Registration failed.";
                }
            }
        }
    }

    public static function Login() {
        // Create a new Database instance
        $db = new Database();

        // Check if fields are empty
        if (empty($_POST['email'])) { echo "Email field is empty"; return; }
        if (empty($_POST['password'])) { echo "Password field is empty"; return; }

        // Escape email
        $email = htmlentities($_POST['email'], ENT_QUOTES);
        $password = $_POST['password'];

        // Check if user exists
        $query = $db->prepare("SELECT * FROM users WHERE email = :email;");
        $query->execute(array(':email' => $email));

        $count =  $query->rowCount();
        if ($count == 1) {
            $result = $query->fetch();

            // If user exists and password matches with email, 
            // Create session and set some basic session variables
            // Else, show error
            if (password_verify($password, $result->password)) {
                Session::Init();
                Session::Set('user_logged_in', true);
                Session::Set('user_id', $result->id);
                Session::Set('user_email', $result->email);
                Session::Set('user_name', $result->name);

                echo "Login successful.";
                return;
            } else {
                echo "Wrong password.";
                return;
            }
        } else {
            echo "User doesn't exist.";
            return;
        }
    }

    public static function Logout() {
        // Destroy session and logout the user

        // IZ NEPOZNATIH RAZLOGA, SESSION NECE DA SE OBRISE

        Session::Init();
        Session::Destroy();
    }
}

?>