<?php

// Database parameters
// Change them to match your environment
define("DB_HOST", "localhost");
define("DB_NAME", "quantox");
define("DB_USER", "root");
define("DB_PASS", "");


// URL of the application
// Change to match your environment
define("URL", "http://192.168.0.103/Quantox2/");

?>