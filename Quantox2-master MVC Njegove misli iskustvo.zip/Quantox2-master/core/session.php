<?php

// Just a basic session helper class
class Session {
    public static function Init() {
        //if (session_id() == '') {
            session_start();
        //}
    }

    public static function Set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public static function Get($key) {
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        } else {
            return null;
        }
    }

    public static function Destroy() {
        session_unset();
        session_destroy();
    }
}
