<?php

class Search {
    public static function Query($string) {
        $db = new Database();

        $query = $db->prepare("SELECT id, name, email FROM `users` WHERE name LIKE '%$string%' OR email LIKE '%$string%';");
        $query->execute(array());

        if ($query->rowCount() == 0) {
            return 0;
        } else {
            return $query->fetchAll();
        }
    }
}

?>