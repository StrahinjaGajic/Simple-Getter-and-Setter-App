<?php

class View {
    public static function Render($page) {
        Session::Init();
        
        include("template/header.php");
        
        // Check if requested page exists, if it exists,
        // show it to the user, if not, show error page
        if(file_exists("pages/".$page.".php")) {
            include("pages/".$page.".php");
        } else {
            include("pages/error.php");
        }
        
        include("template/footer.php");
    }

    public static function Redirect($location, $permanent = false) {
        if ($permanent) {
            header('HTTP/1.1 301 Moved Permanently');
        }
        header('Location: '.$location);
        exit();
    }
}

?>